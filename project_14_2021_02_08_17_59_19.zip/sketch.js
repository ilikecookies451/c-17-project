var PLAY = 1;
var END = 0;
var gameState = PLAY;

var level=1;

var background2,background3;

var You_won,You_wonImg;

var sword;
var swordImg1, swordImg2;

var background1, backgroundImg, background2Img, background3Img;

var monster01, monster01Img;

var monster02, monster02Img;

var score;

var gameover, gameoverImg;

var fruit1, fruit2, fruit3, fruit4, fruit1Img, fruit2Img, fruit3Img, fruit4Img;

function preload() {
  backgroundImg = loadAnimation("background1.png");
  background2Img = loadAnimation("background2.png");
  background3Img = loadAnimation("background3.png");
  
  You_wonImg = loadImage("You won.png");
  
  swordImg1 = loadAnimation("sword.png");

  monster01Img = loadAnimation("alien1.png");
  monster02Img = loadAnimation("alien2.png");


  fruit1Img = loadImage("fruit1.png");
  fruit2Img = loadImage("fruit2.png");
  fruit3Img = loadImage("fruit3.png");
  fruit4Img = loadImage("fruit4.png");

}

function setup() {
  createCanvas(400, 400);

  background1 = createSprite(200, 200, 400, 400);
  background1.addAnimation("background", backgroundImg);
  
  background2 = createSprite(200,200,400,400)
  background2.addAnimation("background2",background3Img);
  background2.visible = false;
  
  background3 = createSprite(200,200,400,400)
  background3.addAnimation("background2",background3Img);
  background3.visible = false;
  
  gameoverImg = loadImage("gameover.png");

  sword = createSprite(200, 350, 10, 10);
  sword.addAnimation("sword", swordImg1);
  sword.scale = 0.5;

  fruit1 = createSprite(0, Math.round(random(30, 300)), 1, 1);
  fruit2 = createSprite(0, Math.round(random(30, 300)), 1, 1);
  fruit3 = createSprite(0, Math.round(random(30, 300)), 1, 1);
  fruit4 = createSprite(0, Math.round(random(30, 300)), 1, 1);
  monster01 = createSprite(0, Math.round(random(30, 300)), 1, 1);
  monster02 = createSprite(0, Math.round(random(30, 300)), 1, 1);

  fruit4 = createSprite(0, Math.round(random(30, 300)), 1, 1);

  gameover = createSprite(200, 200, 400, 400);
  You_won = createSprite(200, 200, 400, 400);
  score = 0;
  
}

function draw() {
  background(220);

   if (keyDown("R") && gameState == END) {
    gameState = PLAY;
    score = 0;
    
    var select_background = Math.round(random(1,3));
    
     if( select_background==1 )
        {
          background1.visible=false;
          
          background2.visible = true;
        }
    
    else if( select_background==2 )
        {
          background1.visible=false;
          background2.visible = false;
          background3.visible = true;
        }
     
     
    else
        {
          background1.visible=true;
          background2.visible = false;
          background3.visible = false;
        }
    
    if (sword.isTouching(monster01)) {
     monster01.destroy();
    }

    if (sword.isTouching(monster02)) {
     monster02.destroy();
    }
    
    level=level+1;
      
    
  }
  
  if(background1.x==0)
  {
   background1.x = background1.width /2; 
  }
  
  if(background2.x==0)
  {
   background2.x = background2.width /2; 
  }
  
  
  if(background3.x==0)
  {
   background3.x = background3.width /2; 
  }
  
  
  You_won.addImage("you won",You_wonImg);
  You_won.visible=false;
  gameover.addImage("gameover", gameoverImg);


  if (gameState == PLAY) {
    gameover.visible = false;

    var select_fruit = Math.round(random(1, 6));
    if (World.frameCount % 80 == 0) {
      if (select_fruit == 1) {
        fruit01();
      } else if (select_fruit == 2) {
        fruit02();
      } else if (select_fruit == 3) {
        fruit03();
      } else if (select_fruit == 4) {
        fruit04();
      } else if (select_fruit == 5) {
        monster1();
      } else {
        monster2();
      }
    }


    if (sword.isTouching(fruit1)) {
      fruit1.destroy();
      
     // playSound("Cut sound.m4a",false);
      
      score = score + 10;

    }

     if (sword.isTouching(fruit2)) {
      fruit2.destroy();
      
      //playSound("Cut sound.m4a",false);
      
      score = score + 10;

    }

    
     if (sword.isTouching(fruit3)) {
      fruit3.destroy();
      
     // playSound("Cut sound.m4a",false);
      
      score = score + 10;

    }

    
     if (sword.isTouching(fruit4)) {
      fruit4.destroy();
      
     // playSound("Cut sound.m4a",false);
      
      score = score + 10;

    }

    

   if (sword.isTouching(monster01)) {
     gameState = END;
    }
    
    if (sword.isTouching(monster02)) {
     gameState = END;
    }


  } else if (gameState == END) {
    gameover.visible = true;

    if(score==40)
    {
      gameover.visible = false;
      score=score;
    }
    
    fruit1.lifetime=-1;
    fruit2.lifetime=-1;
    fruit3.lifetime=-1;
    fruit4.lifetime=-1;
    monster01.lifetime=-1;
    monster02.lifetime=-1;
    
    fruit1.velocityX=0;
    fruit2.velocityX=0;
    fruit3.velocityX=0;
    fruit4.velocityX=0;
    monster01.velocityX=0;
    monster02.velocityX=0;
    

  }

 

 
  /* if(keyDown("space"))
     {
       sword.velocityY=-3;
     
     }*/

  
  
  
  sword.x = World.mouseX;
  sword.y = World.mouseY;


  if (sword.y < 0) {
    sword.velocityY = 0;
    sword.y = 350;

  }
  
if(score==40)
    {
      gameState=END;
        You_won.visible=true;
    }
  
  
  
  drawSprites();

  if (gameState == PLAY) {
    
    stroke(300);
    textSize(25);
    text("Try : "+ level, 30, 30);
  }
  
  
  if (gameState == END && score < 40) {
    textSize(15);
    text("Your Score:" + score, 150, 240);

    textSize(15);
    text("Press R to restart", 150, 270);
  }

  textSize(20);
  text("Score:" + score, 310, 30);
}

function fruit01() {

  fruit1.addImage("fruit", fruit1Img);
  fruit1.scale = 0.25;
  fruit1.velocityX = 3;
  fruit1.lifetime = 120;
  
}

function fruit02() {

  fruit2.addImage("fruit", fruit2Img);
  fruit2.scale = 0.25;
  fruit2.velocityX = 3;
  fruit2.lifetime = 120;

}

function fruit03() {

  fruit3.addImage("fruit", fruit3Img);
  fruit3.scale = 0.20;
  fruit3.velocityX = 3;
  fruit3.lifetime = 120;

}

function fruit04() {
  fruit4.addImage("fruit", fruit4Img);
  fruit4.scale = 0.15;
  fruit4.velocityX = 3;
  fruit4.lifetime = 120;
  
  
}

function monster1() {
  monster01.addAnimation("alien", monster01Img);
  monster01.velocityX = 3;
  monster01.lifetime = 134;

  
}


function monster2() {
  monster02.addAnimation("alien", monster02Img);
  monster02.velocityX = 3;
  monster02.lifetime = 134;
  

}